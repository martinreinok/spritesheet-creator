/****************************************************************************
** Meta object code from reading C++ file 'spritesheetcreator.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../spritesheetcreator.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'spritesheetcreator.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSSpritesheetCreatorENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSSpritesheetCreatorENDCLASS = QtMocHelpers::stringData(
    "SpritesheetCreator",
    "load_images",
    "",
    "add_images_to_table",
    "list_of_files",
    "eventFilter",
    "obj",
    "QEvent*",
    "event",
    "calculate_sheet_size",
    "rows_and_columns_logic",
    "error_messagebox",
    "error_message",
    "save_button",
    "show_spritesheet_preview",
    "on_actionClear_All_triggered",
    "on_actionLoad_Files_changed",
    "on_actionSpritesheet_Preview_changed"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSSpritesheetCreatorENDCLASS_t {
    uint offsetsAndSizes[36];
    char stringdata0[19];
    char stringdata1[12];
    char stringdata2[1];
    char stringdata3[20];
    char stringdata4[14];
    char stringdata5[12];
    char stringdata6[4];
    char stringdata7[8];
    char stringdata8[6];
    char stringdata9[21];
    char stringdata10[23];
    char stringdata11[17];
    char stringdata12[14];
    char stringdata13[12];
    char stringdata14[25];
    char stringdata15[29];
    char stringdata16[28];
    char stringdata17[37];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSSpritesheetCreatorENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSSpritesheetCreatorENDCLASS_t qt_meta_stringdata_CLASSSpritesheetCreatorENDCLASS = {
    {
        QT_MOC_LITERAL(0, 18),  // "SpritesheetCreator"
        QT_MOC_LITERAL(19, 11),  // "load_images"
        QT_MOC_LITERAL(31, 0),  // ""
        QT_MOC_LITERAL(32, 19),  // "add_images_to_table"
        QT_MOC_LITERAL(52, 13),  // "list_of_files"
        QT_MOC_LITERAL(66, 11),  // "eventFilter"
        QT_MOC_LITERAL(78, 3),  // "obj"
        QT_MOC_LITERAL(82, 7),  // "QEvent*"
        QT_MOC_LITERAL(90, 5),  // "event"
        QT_MOC_LITERAL(96, 20),  // "calculate_sheet_size"
        QT_MOC_LITERAL(117, 22),  // "rows_and_columns_logic"
        QT_MOC_LITERAL(140, 16),  // "error_messagebox"
        QT_MOC_LITERAL(157, 13),  // "error_message"
        QT_MOC_LITERAL(171, 11),  // "save_button"
        QT_MOC_LITERAL(183, 24),  // "show_spritesheet_preview"
        QT_MOC_LITERAL(208, 28),  // "on_actionClear_All_triggered"
        QT_MOC_LITERAL(237, 27),  // "on_actionLoad_Files_changed"
        QT_MOC_LITERAL(265, 36)   // "on_actionSpritesheet_Preview_..."
    },
    "SpritesheetCreator",
    "load_images",
    "",
    "add_images_to_table",
    "list_of_files",
    "eventFilter",
    "obj",
    "QEvent*",
    "event",
    "calculate_sheet_size",
    "rows_and_columns_logic",
    "error_messagebox",
    "error_message",
    "save_button",
    "show_spritesheet_preview",
    "on_actionClear_All_triggered",
    "on_actionLoad_Files_changed",
    "on_actionSpritesheet_Preview_changed"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSSpritesheetCreatorENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   80,    2, 0x08,    1 /* Private */,
       3,    1,   81,    2, 0x08,    2 /* Private */,
       5,    2,   84,    2, 0x08,    4 /* Private */,
       9,    0,   89,    2, 0x08,    7 /* Private */,
      10,    0,   90,    2, 0x08,    8 /* Private */,
      11,    1,   91,    2, 0x08,    9 /* Private */,
      13,    0,   94,    2, 0x08,   11 /* Private */,
      14,    0,   95,    2, 0x08,   12 /* Private */,
      15,    0,   96,    2, 0x08,   13 /* Private */,
      16,    0,   97,    2, 0x08,   14 /* Private */,
      17,    0,   98,    2, 0x08,   15 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QStringList,    4,
    QMetaType::Bool, QMetaType::QObjectStar, 0x80000000 | 7,    6,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject SpritesheetCreator::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSSpritesheetCreatorENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSSpritesheetCreatorENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSSpritesheetCreatorENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<SpritesheetCreator, std::true_type>,
        // method 'load_images'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'add_images_to_table'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QStringList, std::false_type>,
        // method 'eventFilter'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        QtPrivate::TypeAndForceComplete<QObject *, std::false_type>,
        QtPrivate::TypeAndForceComplete<QEvent *, std::false_type>,
        // method 'calculate_sheet_size'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rows_and_columns_logic'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'error_messagebox'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'save_button'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'show_spritesheet_preview'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionClear_All_triggered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionLoad_Files_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_actionSpritesheet_Preview_changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void SpritesheetCreator::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SpritesheetCreator *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->load_images(); break;
        case 1: _t->add_images_to_table((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 2: { bool _r = _t->eventFilter((*reinterpret_cast< std::add_pointer_t<QObject*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QEvent*>>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 3: _t->calculate_sheet_size(); break;
        case 4: _t->rows_and_columns_logic(); break;
        case 5: _t->error_messagebox((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 6: _t->save_button(); break;
        case 7: _t->show_spritesheet_preview(); break;
        case 8: _t->on_actionClear_All_triggered(); break;
        case 9: _t->on_actionLoad_Files_changed(); break;
        case 10: _t->on_actionSpritesheet_Preview_changed(); break;
        default: ;
        }
    }
}

const QMetaObject *SpritesheetCreator::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SpritesheetCreator::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSSpritesheetCreatorENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int SpritesheetCreator::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }
    return _id;
}
QT_WARNING_POP
